# Minecraft: JavaScript Edition

A Minecraft-style survival game that runs entirely in the browser. It uses plain JavaScript and [three.js](https://threejs.org/), with no build step and no install. Every texture and sound is generated in code.

## Play

**Online:** `https://<your-github-username>.github.io/<repo-name>/` (see [Deploy](#deploy-to-github-pages) below)

**Locally:** you need a web browser and, ideally, a tiny local server:

```bash
# from the project folder
python3 -m http.server 8000 --bind 0.0.0.0
```

Then open the game at your computer's network IP rather than `localhost`, so other devices on the same Wi-Fi can open it too:

```bash
# macOS: prints your IP, for example 192.168.50.169
ipconfig getifaddr en0
```

Open `http://<your-ip>:8000` (on Windows, `ipconfig` shows the IPv4 address; on Linux, `hostname -I`). When you host from that address, the invite link works for anyone on the same network. Friends on the internet still join from the deployed site with the room code.

If another device cannot open the page, allow incoming connections for Python when your firewall asks (macOS: System Settings → Network → Firewall).

Opening `index.html` directly also works in most browsers, but a local server is more reliable.

> Use a desktop browser (Chrome, Edge, Firefox or Safari) with a mouse and keyboard. The game uses pointer lock and needs an internet connection to load three.js (and PeerJS for multiplayer) from a CDN.

## Controls

| Key | Action |
| --- | --- |
| `W` `A` `S` `D` | Move |
| `Space` | Jump / swim up |
| `Shift` | Sprint |
| Mouse | Look around |
| Left click (hold) | Mine a block / attack |
| Right click | Place a block, eat (hold), open a door, open a Crafting Table or Furnace, sleep in a bed, trade with a villager, till with a hoe, plant seeds, use bone meal, feed animals, use an Eye of Ender |
| `E` | Inventory and 2x2 crafting |
| Inventory: drag and drop | Left button only. Press on a stack, drag it to a slot and release to drop it all there. Hold and sweep across several slots to split it evenly. Right-click does nothing in the inventory |
| `1`-`9` / scroll | Select hotbar slot |
| `Q` | Drop an item (`Ctrl+Q`: the whole stack) |
| `R` | Cycle armor tier |
| `F5` / `V` | Camera view: first person, third person behind, third person in front |
| `F3` | Coordinates, facing direction, debug info |
| `T` / `Enter` | Chat and commands |
| `Esc` | Pause |

## What is in the game

- **Infinite procedural world:** plains, forest and desert biomes, lakes, trees, flowers, tall grass, coal, iron and diamond ore. Every world has a seed.
- **Saved worlds:** worlds are saved in your browser (autosave every 30 seconds, on quit, and when you close the tab), including every block you changed, your inventory and the dragon fight. Create, play and delete worlds from **Singleplayer**.
- **Game modes:** Survival, or Creative (unlimited blocks, instant mining, no damage, double-tap `Space` to fly).
- **Survival:** hearts, hunger, armor tiers, oxygen underwater, fall damage, XP and a 24-hour day/night cycle.
- **Hints:** toast messages tell you when you craft something, when you collect enough materials to unlock a recipe, when night is coming, and when a monster is nearby.
- **Mobs:** pigs, cows, chickens, sheep and horses by day, and they drop raw meat. Creepers, skeletons (they shoot arrows), zombies and spiders at night. Torches light the area and keep monsters from spawning nearby.
- **Crafting and tools:** log -> planks -> sticks -> crafting table -> wooden, stone, iron and diamond pickaxes, swords, axes, shovels and hoes. Pickaxe tier decides what a block drops (iron ore needs stone, diamond needs iron); axes and shovels mine wood and dirt faster. Tools wear out: a bar shows how much use is left. Shift-click moves items quickly.
- **Furnace and smelting:** 8 cobblestone make a furnace. Smelt iron ore into ingots, sand into glass, cobblestone into stone, raw meat into cooked meat and logs into coal, using coal, wood or sticks as fuel. It keeps working while you walk away.
- **Doors:** 6 planks make 3 oak doors. Right-click to open or close. There is no separate double-door item: place two doors side by side and they form a double door that opens together.
- **Beds and sleeping:** sheep drop wool; 3 wool + 3 planks make a bed. Right-click it to set your respawn point, and at night to sleep until morning (not with monsters nearby).
- **Farming:** craft a hoe, till dirt into farmland (keep it near water), plant wheat seeds from tall grass, speed it up with bone meal from skeleton bones, and bake bread from 3 wheat. Hold wheat or seeds to lead cows, pigs and chickens, and feed two to breed a baby.
- **Villages and villagers:** villages grow on flat plains with a well, gravel paths, lamp posts and houses that are all different (size, walls, roof, single or double doors, a bed inside, wheat fields for farmers). Villagers (Farmer, Toolsmith, Mason, Cleric) wander by day and go home at night. Right-click one to trade with emeralds, which you mine from Emerald Ore (deep underground, Stone Pickaxe) or earn by selling goods.
- **The End and the Ender Dragon:** find a hidden stronghold with Eyes of Ender, light the End portal, destroy the crystals and defeat the dragon. See [docs/end_and_dragon.md](docs/end_and_dragon.md).
- **Animated title screen:** a slowly spinning floating island with the game's mobs and terrain, with ambient music.

### Getting started (survival)

You start with empty hands. Punch a tree for logs, press `E` and craft planks, then craft a crafting table (4 planks), place it and right-click it for the 3x3 grid. Make a pickaxe to mine stone and ore.

### Chat commands

Press `T`, then type a command:

| Command | What it does |
| --- | --- |
| `/locate` | Prints the stronghold coordinates (`/locate village` finds the nearest village) |
| `/camera first` / `back` / `front` | Picks the camera view |
| `/gamemode creative` / `survival` | Switches game mode |
| `/invite` | Prints the room code and invite link while hosting |
| `/give <item> [n]` | Gives items, for example `/give diamond 12` or `/give eye_of_ender 9` |
| `/tp end` / `stronghold` / `village` / `home` / `x y z` | Teleports you |
| `/time set day` / `night` | Sets the time of day |

## Play with friends online

Multiplayer is peer-to-peer (WebRTC through [PeerJS](https://peerjs.com/)), so it works on any static host such as GitHub Pages, Vercel or Cloudflare Workers, with no game server to run.

**Host (you):**
1. Open the deployed site, click **Multiplayer -> Host New Server** (or **Host Local Server** on the title screen).
2. Pick a player name and keep the generated **room code** (or type your own).
3. Click **Start & Host Server**. Once you are in the world, an **invite link** is shown in chat (and copied to your clipboard). `/invite` prints it again, and the room code is shown top-left.
4. Send the code or link to your friends and **keep your tab open**. The host's browser is the hub for the room.

**Friends:**
1. Open the invite link (it fills in the code), or open the site and click **Multiplayer -> Direct Connect**.
2. Enter the room code and a name, then click **Join Server**.

Up to 8 players per room. Everyone sees each other's movement, held item and chat, and every block placed or broken. Friends who join late receive all the changes made so far.

**Good to know:**
- The world terrain is identical for everyone (fixed seed). Mobs, the Ender Dragon and the End are **not** synchronised: each player simulates their own, so fight the dragon on your own screen.
- If the host closes the tab, the room ends. Friends play on the host's seed and see the same blocks. The host's world is saved in the host's browser.
- Room codes are registered on PeerJS's free public signalling server (`0.peerjs.com`). It is fine for friends, but it is best-effort. For something more reliable, run your own [PeerServer](https://github.com/peers/peerjs-server) and set `host`, `port`, `path` and `secure` in `PEER_CONFIG` in `game.js`.
- Most home networks connect directly. Some strict firewalls and mobile networks need a TURN relay, which is not included: add one to `iceServers` in `PEER_CONFIG` if a friend cannot connect.
- **Production or local:** the game detects where it is running. On your deployed site (Cloudflare, Vercel...) the invite link is that site's address. On `localhost` (a dev server or a local copy) the host window says so and the link only works on this computer, so friends elsewhere open your deployed game, click **Multiplayer -> Direct Connect** and type the room code. There is nothing to configure.
- **You stay the same player.** Your browser keeps a permanent player id and name. Quit with **Save & Quit** and the room is saved with its world; later, **Multiplayer** shows it as "Created by you" with a **Host Again** button (typing your own room code into Direct Connect does the same), and you come back as the creator with your inventory and builds. The room is only open to friends while you are hosting.
- **Guests are remembered too.** The host's world keeps each friend's inventory, stats and position by their player id, so a friend who leaves and rejoins the same room gets their things back. If the same account is already in the room (for example you open a second tab), the second one joins as a temporary extra player and is not saved.
- **Friends cannot connect?** Most networks connect directly. Strict firewalls and mobile networks need a relay (TURN). When the game is deployed as a Cloudflare Worker (see [Deploy to Cloudflare](#deploy-to-cloudflare-workers)), add a relay's details to the Worker: a free provider such as Metered Open Relay (`TURN_URLS`, `TURN_USERNAME`, `TURN_CREDENTIAL`) or Cloudflare's own TURN (`TURN_KEY_ID`, `TURN_KEY_API_TOKEN`). `worker/index.js` serves them at `/api/turn`; without them the game simply uses direct connections. Open `https://<your-site>/api/turn` to check: `"status":"ok"` means the relay works.
- **Player names are unique in a room** (upper/lower case ignored). If your name is taken, Direct Connect says so and fills in a free one (for example `Steve2`); click Join again to use it.
- Anyone with the code can join, so share it only with friends.

## Deploy to Cloudflare Workers

This is the recommended host, because it also runs the relay (`/api/turn`) that lets friends on strict networks connect. `wrangler.jsonc` serves the game files as static assets and runs `worker/index.js` for `/api/turn`; `.assetsignore` keeps the README, docs and Worker code off the site.

1. In the Cloudflare dashboard, open **Workers & Pages -> Create -> Import a repository** and pick this GitHub repo. Leave the build command empty and the deploy command as `npx wrangler deploy`.
2. Get relay (TURN) details. Pick one:
   - **Free, no card (recommended):** sign up for [Metered Open Relay](https://www.metered.ca/tools/openrelay/) (20 GB a month free). In its dashboard, copy the TURN server addresses, the username and the password.
   - **Cloudflare Realtime TURN:** create a key under **Realtime -> TURN Server**. Free up to 1,000 GB a month, then billed per GB.
3. In the Worker, open **Settings -> Variables and secrets** and add the variables for the option you chose, then click **Deploy**:

   | Option | Name | Value | Type |
   | --- | --- | --- | --- |
   | Any provider (Metered...) | `TURN_URLS` | the relay addresses, comma-separated, e.g. `turn:global.relay.metered.ca:80,turns:global.relay.metered.ca:443?transport=tcp` | Text |
   | | `TURN_USERNAME` | the relay username | Text |
   | | `TURN_CREDENTIAL` | the relay password | Secret |
   | Cloudflare | `TURN_KEY_ID` | the TURN key's ID | Text |
   | | `TURN_KEY_API_TOKEN` | the TURN key's API token | Secret |

4. Push a commit (or retry the latest deployment), then open `https://<your-worker>.workers.dev/api/turn`:
   - `"status":"ok"`: the relay works.
   - `"status":"not-configured"`: the variables are missing or misspelled.
   - `"status":"cloudflare-error-401"` (or 403/404): the key ID or token is wrong.

To deploy from your computer instead: `npx wrangler deploy`.

## Deploy to GitHub Pages

1. Create a GitHub repository and push these files to the `main` branch:

   ```bash
   git init
   git add .
   git commit -m "Minecraft JavaScript Edition"
   git branch -M main
   git remote add origin https://github.com/<your-github-username>/<repo-name>.git
   git push -u origin main
   ```

2. On GitHub open **Settings -> Pages**.
3. Under **Build and deployment**, set **Source** to **Deploy from a branch**, pick branch **main** and folder **/ (root)**, then save.
4. After a minute or two the site is live at `https://<your-github-username>.github.io/<repo-name>/`. Send that link to your friends.

Any other static host works the same way (Netlify, Vercel): upload the folder and serve `index.html`. These hosts do not run the relay, so friends on strict networks may not be able to connect.

## Project layout

```
index.html        Page structure: title screen, menus, HUD, inventory windows
style.css         All styling
game.js           The whole game: world, rendering, mobs, crafting, the End
held-tool.js      First-person hand overlay: tool/sword/bow poses, swing, bow draw, sword slash effect
held-tool.css     Pose math, swing and enchant-glint keyframes for that overlay
loading_poster.jpg  Loading screen artwork
worker/index.js   Cloudflare Worker: serves the game and the /api/turn relay credentials
wrangler.jsonc    Cloudflare Worker config (.assetsignore lists files not to publish)
docs/             Design notes and roadmap
```

## Tech

- [three.js](https://threejs.org/) r128 (loaded from a CDN)
- [PeerJS](https://peerjs.com/) 1.5.4 for online multiplayer (loaded from a CDN)
- Plain JavaScript, no bundler
- Web Audio API for generated sound effects
- A canvas-generated 16x16 texture atlas

## Disclaimer

This is a fan-made, educational project and is not affiliated with Mojang or Microsoft. Minecraft is a trademark of Mojang AB.
# minecraft-javascript-edition-v1.0.0
